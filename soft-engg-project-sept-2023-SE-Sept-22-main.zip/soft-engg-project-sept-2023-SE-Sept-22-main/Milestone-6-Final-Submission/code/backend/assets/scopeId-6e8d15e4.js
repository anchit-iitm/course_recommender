import{as as o}from"./index-af240f69.js";function c(){const e=o("useScopeId").vnode.scopeId;return{scopeId:e?{[e]:""}:void 0}}export{c as u};
