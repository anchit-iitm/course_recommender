/* empty css              */import{f as r}from"./index-af240f69.js";const p=r("v-spacer","div","VSpacer");export{p as V};
