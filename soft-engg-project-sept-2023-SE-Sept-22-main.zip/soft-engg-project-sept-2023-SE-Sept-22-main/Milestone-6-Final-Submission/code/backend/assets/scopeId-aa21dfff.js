import{as as o}from"./index-60217f6b.js";function c(){const e=o("useScopeId").vnode.scopeId;return{scopeId:e?{[e]:""}:void 0}}export{c as u};
