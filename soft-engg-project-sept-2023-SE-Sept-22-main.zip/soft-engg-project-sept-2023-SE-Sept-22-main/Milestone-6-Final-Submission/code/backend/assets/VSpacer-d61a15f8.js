/* empty css              */import{f as r}from"./index-363aa5c7.js";const p=r("v-spacer","div","VSpacer");export{p as V};
