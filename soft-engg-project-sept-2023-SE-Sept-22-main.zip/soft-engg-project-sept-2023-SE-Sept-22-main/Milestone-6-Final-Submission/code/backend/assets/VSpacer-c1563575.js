/* empty css              */import{f as r}from"./index-60217f6b.js";const p=r("v-spacer","div","VSpacer");export{p as V};
