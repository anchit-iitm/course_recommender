import{aL as o}from"./index-363aa5c7.js";function c(){const e=o("useScopeId").vnode.scopeId;return{scopeId:e?{[e]:""}:void 0}}export{c as u};
