<template>
  <!-- <HelloWorld /> -->
  <LoginForm />
</template>

<script setup>
  import LoginForm from '@/components/LoginForm.vue';
</script>
